import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    for record in event['Records']:
        try:
            # Simulação da notificação ao BACEN
            logger.info(f"Notificação ao BACEN reprocessada com sucesso: {record['body']}")
            # Aqui você adicionaria a lógica de reenvio ao BACEN
        except Exception as e:
            logger.error(f"Erro ao notificar o BACEN: {str(e)}")

    return {
        'statusCode': 200,
        'body': json.dumps('Executado com sucesso')
    }
